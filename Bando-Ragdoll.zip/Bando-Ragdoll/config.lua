Config = {}

-- The key used to activate ragdoll (default: U)
Config.RagdollKey = 303 -- U key
