fx_version 'cerulean'
game 'gta5'

lua54 'yes'

author 'Bando'
description 'ragdoll script'
version '1.0.0'

client_scripts {
    'config.lua',
    'client.lua'
}

escrow_ignore {
    'config.lua',
    'client.lua'
  }
